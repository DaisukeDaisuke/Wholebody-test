# FOCUS foot refinement: measured image results

12 people / 4 images. Same annotations and PCK normalization as benchmark.py.

| Condition | Method | Foot points | PCK@0.2 | Mean px | Invalid |
|---|---|---:|---:|---:|---:|
| clean | rtmw_l | 37 | 0.4054 | 4.691 | 0 |
| clean | focus-foot8-one2many/person_crop/direct | 37 | 0.4865 | 11.003 | 0 |
| clean | focus-foot8-one2many/person_crop/selective | 37 | 0.5405 | 9.281 | 0 |
| clean | focus-foot8-one2many/person_crop/associated | 37 | 0.5676 | 4.544 | 0 |
| clean | focus-foot8-one2many/person_crop/associated_blend | 37 | 0.4865 | 4.398 | 0 |
| clean | focus-foot8-one2many/predicted_foot_crop/direct | 37 | 0.1081 | 63.426 | 14 |
| clean | focus-foot8-one2many/predicted_foot_crop/selective | 37 | 0.2432 | 31.108 | 0 |
| clean | focus-foot8-one2one/person_crop/direct | 37 | 0.4595 | 9.324 | 0 |
| clean | focus-foot8-one2one/person_crop/selective | 37 | 0.5405 | 7.635 | 0 |
| clean | focus-foot8-one2one/person_crop/associated | 37 | 0.5405 | 4.698 | 0 |
| clean | focus-foot8-one2one/person_crop/associated_blend | 37 | 0.5135 | 4.508 | 0 |
| clean | focus-foot8-one2one/predicted_foot_crop/direct | 37 | 0.1081 | 59.109 | 19 |
| clean | focus-foot8-one2one/predicted_foot_crop/selective | 37 | 0.2432 | 30.935 | 0 |
| foot | rtmw_l | 37 | 0.3514 | 6.217 | 0 |
| foot | focus-foot8-one2many/person_crop/direct | 37 | 0.2432 | 20.422 | 3 |
| foot | focus-foot8-one2many/person_crop/selective | 37 | 0.3514 | 10.540 | 0 |
| foot | focus-foot8-one2many/person_crop/associated | 37 | 0.3514 | 7.665 | 0 |
| foot | focus-foot8-one2many/person_crop/associated_blend | 37 | 0.4054 | 6.397 | 0 |
| foot | focus-foot8-one2many/predicted_foot_crop/direct | 37 | 0.0270 | 59.069 | 14 |
| foot | focus-foot8-one2many/predicted_foot_crop/selective | 37 | 0.2432 | 26.815 | 0 |
| foot | focus-foot8-one2one/person_crop/direct | 37 | 0.1351 | 15.897 | 3 |
| foot | focus-foot8-one2one/person_crop/selective | 37 | 0.2432 | 11.142 | 0 |
| foot | focus-foot8-one2one/person_crop/associated | 37 | 0.2432 | 8.295 | 0 |
| foot | focus-foot8-one2one/person_crop/associated_blend | 37 | 0.3514 | 6.749 | 0 |
| foot | focus-foot8-one2one/predicted_foot_crop/direct | 37 | 0.0270 | 45.614 | 14 |
| foot | focus-foot8-one2one/predicted_foot_crop/selective | 37 | 0.2162 | 26.803 | 0 |

## Scope

All candidates, failures and mask-only results are retained in foot-report.json.
The selected candidate is a diagnostic result, with no claim of five-toe articulation, independent generalization, or video accuracy.
Ground-truth person boxes are shared by both baselines; foot crops come only from predictions.
