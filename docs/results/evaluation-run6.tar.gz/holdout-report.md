# 開発例と分離した32画像での固定ルール検証
実行: 2026-11-02T02:41:26.042126+00:00
注釈 SHA-256: f8272e9c12f3a42457033ebc75da1167546edf1be5e2ffaf586d6ee97541ff6e
旧4画像を除外し、各画像の最大有効人物を先に固定。その人物に手足注釈がある画像からhash順32件を選んだ。
検出人物cropと正解人物cropのreferenceを別々に表示する。選択・閾値・重みはこの結果を見て変更していない。
|条件|入力|手法|部位|点数|無効予測|平均誤差px|PCK@.10|PCK@.20|
|---|---|---|---|---:|---:|---:|---:|---:|
|clean|detected_person|wholebody|body|477|0|21.729|0.906|0.912|
|clean|detected_person|wholebody|hand|1132|0|18.520|0.479|0.747|
|clean|detected_person|wholebody|foot|157|0|33.296|0.280|0.605|
|clean|detected_person|hand_selective|body|477|0|21.729|0.906|0.912|
|clean|detected_person|hand_selective|hand|1132|0|18.407|0.510|0.754|
|clean|detected_person|hand_selective|foot|157|0|33.296|0.280|0.605|
|clean|detected_person|hand_selective_foot_one2many_associated|body|477|0|21.729|0.906|0.912|
|clean|detected_person|hand_selective_foot_one2many_associated|hand|1132|0|18.407|0.510|0.754|
|clean|detected_person|hand_selective_foot_one2many_associated|foot|157|0|34.403|0.210|0.497|
|clean|detected_person|hand_selective_foot_one2many_blend|body|477|0|21.729|0.906|0.912|
|clean|detected_person|hand_selective_foot_one2many_blend|hand|1132|0|18.407|0.510|0.754|
|clean|detected_person|hand_selective_foot_one2many_blend|foot|157|0|33.646|0.287|0.567|
|clean|detected_person|hand_selective_foot_one2one_associated|body|477|0|21.729|0.906|0.912|
|clean|detected_person|hand_selective_foot_one2one_associated|hand|1132|0|18.407|0.510|0.754|
|clean|detected_person|hand_selective_foot_one2one_associated|foot|157|0|34.232|0.229|0.503|
|clean|detected_person|hand_selective_foot_one2one_blend|body|477|0|21.729|0.906|0.912|
|clean|detected_person|hand_selective_foot_one2one_blend|hand|1132|0|18.407|0.510|0.754|
|clean|detected_person|hand_selective_foot_one2one_blend|foot|157|0|33.615|0.280|0.580|
|clean|gt_person_reference|wholebody|body|477|0|4.998|0.998|1.000|
|clean|gt_person_reference|wholebody|hand|1132|0|4.313|0.534|0.801|
|clean|gt_person_reference|wholebody|foot|157|0|9.726|0.395|0.682|
|clean|gt_person_reference|hand_selective|body|477|0|4.998|0.998|1.000|
|clean|gt_person_reference|hand_selective|hand|1132|0|4.092|0.564|0.814|
|clean|gt_person_reference|hand_selective|foot|157|0|9.726|0.395|0.682|
|clean|gt_person_reference|hand_selective_foot_one2many_associated|body|477|0|4.998|0.998|1.000|
|clean|gt_person_reference|hand_selective_foot_one2many_associated|hand|1132|0|4.092|0.564|0.814|
|clean|gt_person_reference|hand_selective_foot_one2many_associated|foot|157|0|11.474|0.229|0.541|
|clean|gt_person_reference|hand_selective_foot_one2many_blend|body|477|0|4.998|0.998|1.000|
|clean|gt_person_reference|hand_selective_foot_one2many_blend|hand|1132|0|4.092|0.564|0.814|
|clean|gt_person_reference|hand_selective_foot_one2many_blend|foot|157|0|10.270|0.338|0.650|
|clean|gt_person_reference|hand_selective_foot_one2one_associated|body|477|0|4.998|0.998|1.000|
|clean|gt_person_reference|hand_selective_foot_one2one_associated|hand|1132|0|4.092|0.564|0.814|
|clean|gt_person_reference|hand_selective_foot_one2one_associated|foot|157|0|11.577|0.255|0.510|
|clean|gt_person_reference|hand_selective_foot_one2one_blend|body|477|0|4.998|0.998|1.000|
|clean|gt_person_reference|hand_selective_foot_one2one_blend|hand|1132|0|4.092|0.564|0.814|
|clean|gt_person_reference|hand_selective_foot_one2one_blend|foot|157|0|10.386|0.331|0.618|
|hand|detected_person|wholebody|body|477|6|23.700|0.864|0.887|
|hand|detected_person|wholebody|hand|1132|21|22.269|0.210|0.496|
|hand|detected_person|wholebody|foot|157|3|34.250|0.261|0.554|
|hand|detected_person|hand_selective|body|477|6|23.700|0.864|0.887|
|hand|detected_person|hand_selective|hand|1132|21|22.028|0.230|0.496|
|hand|detected_person|hand_selective|foot|157|3|34.250|0.261|0.554|
|hand|detected_person|hand_selective_foot_one2many_associated|body|477|6|23.700|0.864|0.887|
|hand|detected_person|hand_selective_foot_one2many_associated|hand|1132|21|22.028|0.230|0.496|
|hand|detected_person|hand_selective_foot_one2many_associated|foot|157|3|35.586|0.210|0.446|
|hand|detected_person|hand_selective_foot_one2many_blend|body|477|6|23.700|0.864|0.887|
|hand|detected_person|hand_selective_foot_one2many_blend|hand|1132|21|22.028|0.230|0.496|
|hand|detected_person|hand_selective_foot_one2many_blend|foot|157|3|34.617|0.261|0.529|
|hand|detected_person|hand_selective_foot_one2one_associated|body|477|6|23.700|0.864|0.887|
|hand|detected_person|hand_selective_foot_one2one_associated|hand|1132|21|22.028|0.230|0.496|
|hand|detected_person|hand_selective_foot_one2one_associated|foot|157|3|35.710|0.217|0.446|
|hand|detected_person|hand_selective_foot_one2one_blend|body|477|6|23.700|0.864|0.887|
|hand|detected_person|hand_selective_foot_one2one_blend|hand|1132|21|22.028|0.230|0.496|
|hand|detected_person|hand_selective_foot_one2one_blend|foot|157|3|34.794|0.248|0.497|
|hand|gt_person_reference|wholebody|body|477|0|5.076|0.998|1.000|
|hand|gt_person_reference|wholebody|hand|1132|0|6.578|0.249|0.592|
|hand|gt_person_reference|wholebody|foot|157|0|9.644|0.408|0.701|
|hand|gt_person_reference|hand_selective|body|477|0|5.076|0.998|1.000|
|hand|gt_person_reference|hand_selective|hand|1132|0|6.472|0.280|0.587|
|hand|gt_person_reference|hand_selective|foot|157|0|9.644|0.408|0.701|
|hand|gt_person_reference|hand_selective_foot_one2many_associated|body|477|0|5.076|0.998|1.000|
|hand|gt_person_reference|hand_selective_foot_one2many_associated|hand|1132|0|6.472|0.280|0.587|
|hand|gt_person_reference|hand_selective_foot_one2many_associated|foot|157|0|11.319|0.242|0.548|
|hand|gt_person_reference|hand_selective_foot_one2many_blend|body|477|0|5.076|0.998|1.000|
|hand|gt_person_reference|hand_selective_foot_one2many_blend|hand|1132|0|6.472|0.280|0.587|
|hand|gt_person_reference|hand_selective_foot_one2many_blend|foot|157|0|10.192|0.357|0.650|
|hand|gt_person_reference|hand_selective_foot_one2one_associated|body|477|0|5.076|0.998|1.000|
|hand|gt_person_reference|hand_selective_foot_one2one_associated|hand|1132|0|6.472|0.280|0.587|
|hand|gt_person_reference|hand_selective_foot_one2one_associated|foot|157|0|11.426|0.287|0.535|
|hand|gt_person_reference|hand_selective_foot_one2one_blend|body|477|0|5.076|0.998|1.000|
|hand|gt_person_reference|hand_selective_foot_one2one_blend|hand|1132|0|6.472|0.280|0.587|
|hand|gt_person_reference|hand_selective_foot_one2one_blend|foot|157|0|10.311|0.344|0.631|
|foot|detected_person|wholebody|body|477|0|23.598|0.872|0.899|
|foot|detected_person|wholebody|hand|1132|0|19.423|0.466|0.723|
|foot|detected_person|wholebody|foot|157|0|36.871|0.268|0.516|
|foot|detected_person|hand_selective|body|477|0|23.598|0.872|0.899|
|foot|detected_person|hand_selective|hand|1132|0|19.248|0.502|0.732|
|foot|detected_person|hand_selective|foot|157|0|36.871|0.268|0.516|
|foot|detected_person|hand_selective_foot_one2many_associated|body|477|0|23.598|0.872|0.899|
|foot|detected_person|hand_selective_foot_one2many_associated|hand|1132|0|19.248|0.502|0.732|
|foot|detected_person|hand_selective_foot_one2many_associated|foot|157|0|39.900|0.166|0.350|
|foot|detected_person|hand_selective_foot_one2many_blend|body|477|0|23.598|0.872|0.899|
|foot|detected_person|hand_selective_foot_one2many_blend|hand|1132|0|19.248|0.502|0.732|
|foot|detected_person|hand_selective_foot_one2many_blend|foot|157|0|37.957|0.210|0.433|
|foot|detected_person|hand_selective_foot_one2one_associated|body|477|0|23.598|0.872|0.899|
|foot|detected_person|hand_selective_foot_one2one_associated|hand|1132|0|19.248|0.502|0.732|
|foot|detected_person|hand_selective_foot_one2one_associated|foot|157|0|39.123|0.191|0.401|
|foot|detected_person|hand_selective_foot_one2one_blend|body|477|0|23.598|0.872|0.899|
|foot|detected_person|hand_selective_foot_one2one_blend|hand|1132|0|19.248|0.502|0.732|
|foot|detected_person|hand_selective_foot_one2one_blend|foot|157|0|37.585|0.248|0.446|
|foot|gt_person_reference|wholebody|body|477|0|5.385|0.994|0.998|
|foot|gt_person_reference|wholebody|hand|1132|0|4.291|0.534|0.801|
|foot|gt_person_reference|wholebody|foot|157|0|14.056|0.293|0.605|
|foot|gt_person_reference|hand_selective|body|477|0|5.385|0.994|0.998|
|foot|gt_person_reference|hand_selective|hand|1132|0|4.105|0.563|0.811|
|foot|gt_person_reference|hand_selective|foot|157|0|14.056|0.293|0.605|
|foot|gt_person_reference|hand_selective_foot_one2many_associated|body|477|0|5.385|0.994|0.998|
|foot|gt_person_reference|hand_selective_foot_one2many_associated|hand|1132|0|4.105|0.563|0.811|
|foot|gt_person_reference|hand_selective_foot_one2many_associated|foot|157|0|17.188|0.204|0.389|
|foot|gt_person_reference|hand_selective_foot_one2many_blend|body|477|0|5.385|0.994|0.998|
|foot|gt_person_reference|hand_selective_foot_one2many_blend|hand|1132|0|4.105|0.563|0.811|
|foot|gt_person_reference|hand_selective_foot_one2many_blend|foot|157|0|15.224|0.229|0.503|
|foot|gt_person_reference|hand_selective_foot_one2one_associated|body|477|0|5.385|0.994|0.998|
|foot|gt_person_reference|hand_selective_foot_one2one_associated|hand|1132|0|4.105|0.563|0.811|
|foot|gt_person_reference|hand_selective_foot_one2one_associated|foot|157|0|17.236|0.210|0.389|
|foot|gt_person_reference|hand_selective_foot_one2one_blend|body|477|0|5.385|0.994|0.998|
|foot|gt_person_reference|hand_selective_foot_one2one_blend|hand|1132|0|4.105|0.563|0.811|
|foot|gt_person_reference|hand_selective_foot_one2one_blend|foot|157|0|15.278|0.242|0.497|
## 解釈の範囲
- 32 images were excluded from this PoC's four gate-design images; upstream training/development overlap is not excluded.
- Target selection requires scorable hand and foot annotations and is not a population-representative sample.
- Detected-person and ground-truth-person reference routes are separate; the detector never uses ground truth to pick a box.
- Controlled hand/foot masks use annotation locations only to define perturbations, not inference crops or refinement decisions.
- A missing person detection remains an invalid prediction and a PCK failure for every labeled point.
- Mean pixel error uses finite predictions; invalidPredictionCount must be read alongside it.
- 32 independent images support only limited validation, not production accuracy or temporal/multiview performance.
- COCO foot landmarks are heel, big-toe tip and small-toe tip per foot; five articulated toes are not evaluated.
- Raw scores have model-specific scales and are not calibrated visibility or correctness probabilities.
- Source JPEGs and all masked frames remain in cache and are not included in the numerical artifacts.
## 出典
- https://github.com/jin-s13/COCO-WholeBody#download
- https://github.com/jin-s13/COCO-WholeBody#terms-of-use
- https://huggingface.co/datasets/msdkhairi/coco2017/blob/159fa91cbeccbb944e666a399e43b4cf25e2d3e9/coco_wholebody_val_v1.0.json
- https://huggingface.co/RabbitDaisuke/Foot-Refinement-onnx/tree/c7a40271d743a6cef447ee63c6246399418aa96f
