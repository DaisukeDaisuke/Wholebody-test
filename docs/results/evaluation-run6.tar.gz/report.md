# 実画像・実ONNX推論の小規模評価
実行日時: 2026-11-02T02:39:42.161255+00:00
対象: 4画像・12人物。人物領域は正解BBoxを使用。
この数値は診断用の小規模標本であり、COCO AP、実動画、多視点、利用者のGPU性能の証明ではない。
手の細部再推論は予測された手首・肘・手指からROIを作る。正解手BBoxを入力しない。
PCKは正解に対する誤差を部位サイズで割って採点。低信頼点も分母から除かない。
身体は人物BBoxの最大辺、手は正解手BBoxの最大辺、足は注釈3点の最大幅/高さで正規化。
|条件|処理|部位|点数|平均誤差px|PCK@0.05|PCK@0.10|PCK@0.20|
|---|---|---|---:|---:|---:|---:|---:|
|clean|wholebody|body|181|3.783|0.939|0.983|1.000|
|clean|wholebody|hand|210|3.849|0.148|0.410|0.667|
|clean|wholebody|foot|37|4.689|0.027|0.135|0.405|
|clean|hand_refined|body|181|3.783|0.939|0.983|1.000|
|clean|hand_refined|hand|210|3.641|0.195|0.424|0.686|
|clean|hand_refined|foot|37|4.689|0.027|0.135|0.405|
|clean|hand_selective|body|181|3.783|0.939|0.983|1.000|
|clean|hand_selective|hand|210|3.535|0.186|0.438|0.695|
|clean|hand_selective|foot|37|4.689|0.027|0.135|0.405|
|hand|wholebody|body|181|3.890|0.934|0.983|1.000|
|hand|wholebody|hand|210|6.457|0.043|0.110|0.390|
|hand|wholebody|foot|37|4.736|0.027|0.054|0.432|
|hand|hand_refined|body|181|3.890|0.934|0.983|1.000|
|hand|hand_refined|hand|210|6.437|0.052|0.114|0.414|
|hand|hand_refined|foot|37|4.736|0.027|0.054|0.432|
|hand|hand_selective|body|181|3.890|0.934|0.983|1.000|
|hand|hand_selective|hand|210|6.437|0.052|0.114|0.414|
|hand|hand_selective|foot|37|4.736|0.027|0.054|0.432|
|foot|wholebody|body|181|3.856|0.939|0.983|1.000|
|foot|wholebody|hand|210|3.857|0.143|0.395|0.671|
|foot|wholebody|foot|37|6.193|0.027|0.054|0.378|
|foot|hand_refined|body|181|3.856|0.939|0.983|1.000|
|foot|hand_refined|hand|210|3.645|0.195|0.419|0.686|
|foot|hand_refined|foot|37|6.193|0.027|0.054|0.378|
|foot|hand_selective|body|181|3.856|0.939|0.983|1.000|
|foot|hand_selective|hand|210|3.541|0.181|0.433|0.695|
|foot|hand_selective|foot|37|6.193|0.027|0.054|0.378|
|torso|wholebody|body|181|4.548|0.912|0.972|0.989|
|torso|wholebody|hand|210|7.274|0.062|0.219|0.543|
|torso|wholebody|foot|37|4.848|0.027|0.081|0.459|
|torso|hand_refined|body|181|4.548|0.912|0.972|0.989|
|torso|hand_refined|hand|210|9.167|0.081|0.214|0.476|
|torso|hand_refined|foot|37|4.848|0.027|0.081|0.459|
|torso|hand_selective|body|181|4.548|0.912|0.972|0.989|
|torso|hand_selective|hand|210|7.197|0.076|0.233|0.557|
|torso|hand_selective|foot|37|4.848|0.027|0.081|0.459|
## 手の再推論による差
改善を合格条件として偽装せず、符号付きの差をそのまま記録する。
clean: 平均誤差差 -0.208px、PCK@0.20差 +0.019。
hand: 平均誤差差 -0.020px、PCK@0.20差 +0.024。
foot: 平均誤差差 -0.212px、PCK@0.20差 +0.014。
torso: 平均誤差差 1.894px、PCK@0.20差 -0.067。
## 手の選択採用による差
hand_selectiveは同じHand5候補へ手首の信頼度・位置整合性・関節の信頼度・crop境界への集中を判定する。
このルールはrun 41375521773の失敗例から設計した探索的改善であり、この小標本での再測定を汎化性能の証明には使わない。
clean: 平均誤差差 -0.314px、PCK@0.20差 +0.029。
hand: 平均誤差差 -0.020px、PCK@0.20差 +0.024。
foot: 平均誤差差 -0.316px、PCK@0.20差 +0.024。
torso: 平均誤差差 -0.077px、PCK@0.20差 +0.014。
## 実際の入力経路: 全画面から予測ROIへ
4画像で、全画面入力から予測した身体・足の23点で次の人物領域を作り、元画像の手を再推論する。
推論に正解BBoxは渡さない。採点対象は画像ごとの最大人物に事前固定し、別人を追った場合の誤差も残す。
同じ静止画を2回使う初期化の診断であり、実動画での追従・フレーム落ち・再捕捉の評価ではない。
|入力経路|部位|点数|平均誤差px|PCK@0.05|PCK@0.10|PCK@0.20|
|---|---|---:|---:|---:|---:|---:|
|full_frame|body|62|109.480|0.500|0.565|0.597|
|full_frame|hand|126|143.484|0.032|0.079|0.190|
|full_frame|foot|17|34.090|0.000|0.118|0.294|
|full_frame_hand_refined|body|62|109.480|0.500|0.565|0.597|
|full_frame_hand_refined|hand|126|154.468|0.008|0.063|0.159|
|full_frame_hand_refined|foot|17|34.090|0.000|0.118|0.294|
|full_frame_hand_selective|body|62|109.480|0.500|0.565|0.597|
|full_frame_hand_selective|hand|126|143.241|0.032|0.079|0.190|
|full_frame_hand_selective|foot|17|34.090|0.000|0.118|0.294|
|predicted_person_crop|body|62|118.465|0.500|0.516|0.516|
|predicted_person_crop|hand|126|147.768|0.016|0.079|0.254|
|predicted_person_crop|foot|17|35.873|0.000|0.176|0.588|
|predicted_person_crop_hand_refined|body|62|118.465|0.500|0.516|0.516|
|predicted_person_crop_hand_refined|hand|126|148.264|0.008|0.048|0.230|
|predicted_person_crop_hand_refined|foot|17|35.873|0.000|0.176|0.588|
|predicted_person_crop_hand_selective|body|62|118.465|0.500|0.516|0.516|
|predicted_person_crop_hand_selective|hand|126|148.137|0.016|0.079|0.254|
|predicted_person_crop_hand_selective|foot|17|35.873|0.000|0.176|0.588|
画像ごとの採点・予測ROI・人物対応の診断はreport.jsonのinitializationExperiment.casesへ、
実座標と手ROIはinitialization-predictions.jsonへ保存する。CC BY画像785の比較はoverlays/785-initialization.jpg。
## 遮蔽の解釈
hand/foot/torsoは元画像上へ矩形を置く制御実験。遮蔽で失われた点だけの成績はreport.jsonのmaskedPointMetricsへ分離。
これは時系列補完や別カメラでの回復を実証する評価ではない。全方向から隠れた指を観測したと扱わない。
## 出典とライセンス
COCO-WholeBodyの注釈は研究・非商用用途（公式READMEのリンク先CC BY-NC 4.0）。画像は各画像のFlickr由来ライセンス。
公開オーバーレイはCC BYの画像785だけ。画像別情報・取得URL・ライセンスはlicense-attribution.json。
MMPose fixture commit: 759b39c13fea6ba094afc1fa932f51dc1b11cbf9
https://github.com/jin-s13/COCO-WholeBody#terms-of-use
https://github.com/open-mmlab/mmpose/tree/main/projects/rtmpose
