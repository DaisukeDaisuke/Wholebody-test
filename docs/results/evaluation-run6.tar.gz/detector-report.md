# 人物検出からの実画像評価
実行: 2026-11-02T02:39:47.894111+00:00
最大のperson検出BBoxを選び、RTMWとHand5選択採用を実行する。正解BBoxはモデル入力・人物選択に使わない。
採点は既存初期化評価と同じ4画像の最大注釈人物へ固定。人物を取り違えた誤差も残す。
|入力経路|部位|点数|平均誤差px|PCK@0.10|PCK@0.20|
|---|---|---:|---:|---:|---:|
|detected_person|body|62|4.417|1.000|1.000|
|detected_person|hand|126|3.545|0.325|0.778|
|detected_person|foot|17|5.400|0.235|0.765|
|detected_person_hand_refined|body|62|4.417|1.000|1.000|
|detected_person_hand_refined|hand|126|2.974|0.444|0.817|
|detected_person_hand_refined|foot|17|5.400|0.235|0.765|
|detected_person_hand_selective|body|62|4.417|1.000|1.000|
|detected_person_hand_selective|hand|126|3.019|0.444|0.817|
|detected_person_hand_selective|foot|17|5.400|0.235|0.765|
|gt_person_reference|body|62|4.544|0.984|1.000|
|gt_person_reference|hand|126|3.281|0.437|0.770|
|gt_person_reference|foot|17|5.009|0.294|0.706|
|gt_person_hand_refined_reference|body|62|4.544|0.984|1.000|
|gt_person_hand_refined_reference|hand|126|3.004|0.484|0.794|
|gt_person_hand_refined_reference|foot|17|5.009|0.294|0.706|
|gt_person_hand_selective_reference|body|62|4.544|0.984|1.000|
|gt_person_hand_selective_reference|hand|126|2.825|0.500|0.810|
|gt_person_hand_selective_reference|foot|17|5.009|0.294|0.706|
検出がない場合も分母から除かずPCK失敗へ数える。平均px誤差は有限予測だけの平均なので、invalidPredictionCountも併記する。
同じ4画像を用いた診断であり、大規模精度保証・実動画・WebGPUの速度評価ではない。
手選択ルールは先行した同じ診断標本の失敗から設計したため、独立な汎化評価ではない。
## 取得元
https://github.com/open-mmlab/mmpose/blob/main/projects/rtmpose/yolox/humanart/yolox_tiny_8xb8-300e_humanart.py
https://github.com/open-mmlab/mmpose/blob/main/projects/rtmpose/yolox/humanart/yolox_s_8xb8-300e_humanart.py
https://github.com/Tau-J/rtmlib/blob/03a1693e59e4f7cd84582c0fb30459b3bf18ad42/rtmlib/tools/object_detection/yolox.py
https://github.com/open-mmlab/mmpose/blob/main/LICENSE
